package WeekFourAssignments;

public class Course {
	String id;
	String name;
	String instructor;
	
	public Course() {
		id = "null";
		name = "null";
		instructor = "null";
	}
	
	public Course(String id, String name, String instructor) {
		this.id = id;
		this.name = name;
		this.instructor = instructor;
	}


}
